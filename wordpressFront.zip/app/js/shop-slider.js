$(document).ready(function() {

	let shopSlider = $(".owl-carousel");

	shopSlider.owlCarousel({
		loop: true,
		margin: 2,
		dots: false,
		smartSpeed: 500,
		responsive: {
			0: {
				items: 1,
			},
			1254: {
				items: 3,
			}
		}
	});

	$('#shopSliderLeft').click(function() {
		shopSlider.trigger('prev.owl.carousel');
	})

	$('#shopSliderRight').click(function() {
		shopSlider.trigger('next.owl.carousel');
	})

});