console.log('Hello, World');
var name = 'Tony'; //глобально
let surname = 'Rohozhnikov'; //локально
const sex = 'Male'; //Констаты не можем менять

//Типы значения 
var name = "Tony Rohozhnikov"; //String
var age = 28.05; //Number
var status = true; //boolean
var variable = null; //null(пустая переменная)
var city; //undefined(значения не  существует);
var person = {name: "Anton",surname: "Rohozhnikov",age: 23} //Object

console.log(person.name,age);
//Операции
var age = 30;
var newAge = age + 10;
var stringOne = "Hello";
var stringTwo = "World";

console.log(newAge);
console.log(stringOne + " " + stringTwo);

var string ="30";

//if(1) -tru, if(0) - falsh
// === проверяем значения и тип
// && - and(и), || - or(или)
if (age > 18) {
	console.log('взрослый');
} else {
	console.log('молодой');
}

var status = (age > 18) ? 'Взрослый' : 'Молодой';
console.log(status);

//Массивы
var fruits = ['apples', 'bananas','oranges'];

fruits.push('berries') //add elemants

console.log(fruits); // 0 - apples 1 - bananas...
console.log(fruits.length); // количество идексов(3)

//switch case
var number = 2;

switch(number) {
	case 1 :
		console.log('там 1');
		break;
	case 2 :
		console.log('там 2');
		break;
	case 3 :
		console.log('там 3');
		break;
	case 4 :
		console.log('там 4');
}

if (number == 1) {
	console.log('там 1');
} else if (number == 2) {
	console.log('там 2(через if)');
} else if (number == 3) {
	console.log('там 3');
} else {
	console.log('там 4');
}


//циклы
var i = 0;
/*for (i = 0; i < fruits.length; i++) {
	console.log('В корзине номер ' + i + ' лежат ' + fruits[i]);
}*/

while(i < fruits.length) {
	console.log('В корзине номер ' + i + ' лежат ' + fruits[i]);
	i++;
}

function mySum(a,b) {
	var summ = a + b;
	//console.log(summ);
	return summ; //данные возвращаються
}

console.log(mySum(2,4));
mySum(7,8);

var person = {
	name : "Tony",
	surname : "Rohozhnikov",
	age : 24,
	// Динамическая ячейка
	fullName : function (a) {
		return this.name + " " + this.surname + " " + a ;
	}
}

console.log(person.fullName('test'));