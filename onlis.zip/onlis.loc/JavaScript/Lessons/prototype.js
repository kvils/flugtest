/*const persone = {
	name: 'Tony',
	age: 23,
	greet: function() {
		console.log('Greet!')
	}
}*/

const persone = new Object({
	name: 'Tony',
	age: 23,
	greet: function() {
		console.log('Greet!')
	}
})

Object.prototype.sayHello = function() {
	console.log('Hello!')
}

const lena = Object.create(persone)
lena.name = 'Elena';

const str = new String('I am string');