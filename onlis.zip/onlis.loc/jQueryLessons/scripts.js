//Дом-дерево(Работа script в head(верху))
//jQuery(document).ready(function() - old release
jQuery(function(){ //new release
	//tag, class, id 
	//$('.first').css({'color':'red'});
	//Передача  данных  при  момощи data
	var id = $('h1').data('id'); //data-(id) .data();

	//alert(id); - Вывод(модальное окно)

	//Attributes
	//$('h2[title="two title"]').css({'color':'red'});
	//$('ul li:first').css({'color':'red'}); //Первый элемент
	//$('ul li:even').css({'color':'red'}); //Четные элементы
	$('ul li:nth-child(3)').css({'color':'red'}); //n-элемент

	// :contains(), :empty, :parent, :has
	//$('h2:contains("life")').css({'color':'red'});
	$('ul li:has(\'span\')').css({'color':'red'}); //красим li только span
	//$('table tr td:parent').css({'background':'red'}); //красим только родителей
	$('table tr td:empty').css({'background':'red'}); //родители которые не имеют контент

	//click(), dblclick, mouseenter, mouseleave
	//$('button').click(function(){alert('test');});
	//сокращенная версия и более склонная к  работе on
	//$('button').on('click',function(){alert('testlocal');}); 
	//$('button').dblclick(function(){alert('1');});
	//$('button').mouseenter(function(){alert('1');});
	$('button').mouseleave(function(){alert('1');});

	//keypress, keydown, keyup
	/*$('input[name="name"]').keyup(function(){
		var value = $(this).val();
		$('input[name="submit"]').val(value);
	});*/

	//change, submit
	/*$('input[name="name"]').change(function(){
		var value = $(this).val();
		$('input[name="submit"]').val(value);
	});*/

	$('form').submit(function(){
		alert('temp');	
	});

	
	//css, hide(), show(), delay(), animate(), fadeIn, fadeOut, attr()
	//(Прячем/показываем  элементы)
	//$('form').css({'display':'none'});
	$('form').hide(5000).delay(5000).show(7000);
	$('#jj').animate({'width':'50px'}, 2000);
	//alert($('input[name="name"]').attr('value'));
	//alert($('.first').attr('data-id'));

	//resize, scroll
	/*$(window).resize(function(){
		//width(), height()
		var width = $(this).width();
		console.log(width);
	});*/
	$(window).scroll(function(){
		//width(), height()
		var width = $(this).width();
		console.log(width);
	});

	//addClass, removeClass, toggleClass
	$('h1').addClass('red');
	/*$('h1').hover(function(){
		$(this).addClass('blue');

		$(this).on('click',function(){
			$(this).removeClass('blue').removeClass('red');
		})
	});*/
	$('h1').click(function(){
		$(this).toggleClass('blue');
	});

	//text(), html()
	//var text = $('.text').text();
	$('.text').text('Новый текст');
	console.log($('ul').html());

	//append prepend
	//$('ul').append('<li>New li</li>'); //add element end
	$('ul').prepend('<li>New li</li>'); //... first

	//remove(), empty() after
	//$('ul').empty(); //очищаем

	//$('ul').after('<span>Hello_span</span>');
	//$('ul li:last-child').after('<li>Hello</li>');

	//wrap unwrap
	$('form').wrap('<div class="red"></div>');

	//slider
  	$('.slider').slick();
	//console.log(text);
	console.log(id);
});

